// hooks/use-geo.ts - 获取用户地理位置的 Hook
import { useState, useEffect } from "react";
import { RegionType } from "@/lib/architecture-modules/core/types";

interface GeoData {
  region: RegionType;
  countryCode?: string;
  isChina: boolean;
  isLoading: boolean;
  error: Error | null;
}

export function useGeo(): GeoData {
  const [geoData, setGeoData] = useState<GeoData>({
    region: RegionType.USA, // 默认海外
    isChina: false,
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    let isMounted = true;

    async function fetchGeo() {
      try {
        const response = await fetch("/api/geo");
        if (!response.ok) {
          throw new Error("Failed to fetch geo data");
        }

        const data = await response.json();

        if (isMounted) {
          setGeoData({
            region: data.region || RegionType.USA,
            countryCode: data.countryCode,
            isChina:
              data.region === RegionType.CHINA || data.countryCode === "CN",
            isLoading: false,
            error: null,
          });
        }
      } catch (error) {
        console.error("Geo detection error:", error);

        if (isMounted) {
          setGeoData({
            region: RegionType.USA,
            isChina: false,
            isLoading: false,
            error: error as Error,
          });
        }
      }
    }

    fetchGeo();

    return () => {
      isMounted = false;
    };
  }, []);

  return geoData;
}
