/**
 * Chat Sessions API
 * GET /api/chat/sessions - 获取用户所有会话
 * POST /api/chat/sessions - 创建新会话
 */

import { NextRequest } from "next/server";
import { supabase } from "@/lib/supabase";
import { supabaseAdmin } from "@/lib/supabase-admin";

/**
 * GET /api/chat/sessions
 * 获取当前用户的所有会话列表
 */
export async function GET(req: NextRequest) {
  try {
    // 鉴权
    const authHeader = req.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const token = authHeader.replace("Bearer ", "");

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return Response.json({ error: "Invalid token" }, { status: 401 });
    }

    // 获取查询参数
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get("limit") || "50");
    const offset = parseInt(searchParams.get("offset") || "0");

    // 查询会话
    const {
      data: sessions,
      error,
      count,
    } = await supabaseAdmin
      .from("gpt_sessions")
      .select("*, gpt_messages(count)", { count: "exact" })
      .eq("user_id", user.id)
      .order("updated_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) {
      console.error("Failed to fetch sessions:", error);
      return Response.json(
        { error: "Failed to fetch sessions" },
        { status: 500 }
      );
    }

    // 返回会话列表
    return Response.json({
      sessions: sessions || [],
      total: count || 0,
      limit,
      offset,
    });
  } catch (error) {
    console.error("Sessions API error:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

/**
 * POST /api/chat/sessions
 * 创建新会话
 */
export async function POST(req: NextRequest) {
  try {
    // 鉴权
    const authHeader = req.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const token = authHeader.replace("Bearer ", "");

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return Response.json({ error: "Invalid token" }, { status: 401 });
    }

    // 解析请求体
    const body = await req.json();
    const { title, model = "gpt-3.5-turbo" } = body;

    // 验证参数
    if (!title || typeof title !== "string" || title.trim().length === 0) {
      return Response.json(
        { error: "title is required and must be a non-empty string" },
        { status: 400 }
      );
    }

    if (title.length > 200) {
      return Response.json(
        { error: "title must be less than 200 characters" },
        { status: 400 }
      );
    }

    // 创建会话
    const { data: session, error } = await supabaseAdmin
      .from("gpt_sessions")
      .insert({
        user_id: user.id,
        title: title.trim(),
        model,
      })
      .select()
      .single();

    if (error) {
      console.error("Failed to create session:", error);
      return Response.json(
        { error: "Failed to create session" },
        { status: 500 }
      );
    }

    return Response.json({ session }, { status: 201 });
  } catch (error) {
    console.error("Create session API error:", error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
