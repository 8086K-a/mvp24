"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  ArrowLeft,
  Settings,
  Moon,
  Sun,
  Globe,
  Bell,
  Shield,
} from "lucide-react";
import { Header } from "@/components/header";
import { useApp } from "@/components/app-context";
import { useUser } from "@/components/user-context";

export default function SettingsPage() {
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [emailUpdates, setEmailUpdates] = useState(true);
  const [autoSave, setAutoSave] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState("");
  const { language, setLanguage, activeView, setActiveView } = useApp();
  const { user } = useUser(); // 移除 refreshUser，因为不再需要

  const router = useRouter();

  // 移除不必要的用户状态刷新，user-context.tsx 已经处理了初始化
  // useEffect(() => {
  //   const checkUserState = async () => {
  //     await refreshUser();
  //   };
  //   checkUserState();
  // }, [refreshUser]);

  const handleSave = async () => {
    setSaving(true);
    setSuccess("");

    // 这里可以保存设置到后端
    // 暂时只是模拟保存过程
    setTimeout(() => {
      setSuccess("设置已保存");
      setSaving(false);
    }, 1000);
  };

  const handleViewChange = (view: string) => {
    setActiveView(view);
    router.push("/");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header activeView={activeView} setActiveView={handleViewChange} />

      <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => router.back()}
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>返回</span>
          </Button>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="w-5 h-5" />
                <span>应用设置</span>
              </CardTitle>
              <CardDescription>自定义您的应用体验</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* 语言设置 */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="flex items-center space-x-2">
                    <Globe className="w-4 h-4" />
                    <span>界面语言</span>
                  </Label>
                  <p className="text-sm text-gray-600">选择您偏好的界面语言</p>
                </div>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="zh">中文</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* 深色模式 */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="flex items-center space-x-2">
                    {darkMode ? (
                      <Moon className="w-4 h-4" />
                    ) : (
                      <Sun className="w-4 h-4" />
                    )}
                    <span>深色模式</span>
                  </Label>
                  <p className="text-sm text-gray-600">切换深色或浅色主题</p>
                </div>
                <Switch checked={darkMode} onCheckedChange={setDarkMode} />
              </div>

              {/* 自动保存 */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>自动保存</Label>
                  <p className="text-sm text-gray-600">编辑时自动保存更改</p>
                </div>
                <Switch checked={autoSave} onCheckedChange={setAutoSave} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Bell className="w-5 h-5" />
                <span>通知设置</span>
              </CardTitle>
              <CardDescription>管理您的通知偏好</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* 推送通知 */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>推送通知</Label>
                  <p className="text-sm text-gray-600">接收应用内推送通知</p>
                </div>
                <Switch
                  checked={notifications}
                  onCheckedChange={setNotifications}
                />
              </div>

              {/* 邮件更新 */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>邮件更新</Label>
                  <p className="text-sm text-gray-600">
                    接收产品更新和新闻邮件
                  </p>
                </div>
                <Switch
                  checked={emailUpdates}
                  onCheckedChange={setEmailUpdates}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="w-5 h-5" />
                <span>隐私与安全</span>
              </CardTitle>
              <CardDescription>管理您的隐私和安全设置</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button variant="outline" className="justify-start">
                  更改密码
                </Button>
                <Button variant="outline" className="justify-start">
                  两步验证
                </Button>
                <Button variant="outline" className="justify-start">
                  下载数据
                </Button>
                <Button
                  variant="outline"
                  className="justify-start text-red-600 hover:text-red-700"
                >
                  删除账户
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* 保存按钮 */}
          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={saving}>
              {saving ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  保存中...
                </>
              ) : (
                <>
                  <Settings className="w-4 h-4 mr-2" />
                  保存设置
                </>
              )}
            </Button>
          </div>

          {/* 成功消息 */}
          {success && (
            <Alert>
              <AlertDescription className="text-green-600">
                {success}
              </AlertDescription>
            </Alert>
          )}
        </div>
      </div>
    </div>
  );
}
