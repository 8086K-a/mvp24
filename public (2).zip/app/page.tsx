"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Sidebar } from "@/components/sidebar";
import { GPTWorkspace } from "@/components/gpt-workspace";
import { GPTLibrary } from "@/components/gpt-library";
import { Header } from "@/components/header";
import { ExportPanel } from "@/components/export-panel";
import { ChatHistory } from "@/components/chat-history";
import { useApp } from "@/components/app-context";
import { useUser } from "@/components/user-context";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";

export default function MultiGPTPlatform() {
  const [selectedGPTs, setSelectedGPTs] = useState<any[]>([]);
  const { activeView, setActiveView } = useApp();
  const { user, loading } = useUser();
  const router = useRouter();
  const [collaborationMode, setCollaborationMode] = useState<
    "parallel" | "sequential"
  >("parallel");

  // 移除强制认证 - 允许游客访问，具体功能内部根据需要检查登录状态

  // Debug模式指示器
  const isDebugMode =
    typeof window !== "undefined" &&
    new URLSearchParams(window.location.search).has("debug");

  const currentDebugRegion =
    typeof window !== "undefined"
      ? new URLSearchParams(window.location.search).get("debug")
      : null;

  // Debug模式切换函数
  const toggleDebugMode = (region: string | null) => {
    const url = new URL(window.location.href);
    if (region) {
      url.searchParams.set("debug", region);
    } else {
      url.searchParams.delete("debug");
    }
    window.location.href = url.toString();
  };

  // 只在初始化时显示加载状态，允许未登录用户访问
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">加载中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header activeView={activeView} setActiveView={setActiveView} />

      {/* Debug模式指示器 */}
      {isDebugMode && (
        <div className="fixed top-16 right-4 bg-yellow-100 border border-yellow-300 rounded-lg px-3 py-2 text-sm z-50">
          <div className="font-medium text-yellow-800">调试模式</div>
          <div className="text-yellow-700">
            区域:{" "}
            {currentDebugRegion === "china"
              ? "中国"
              : currentDebugRegion === "usa"
              ? "美国"
              : "未知"}
          </div>
          <div className="mt-2 flex space-x-2">
            <button
              onClick={() => toggleDebugMode("china")}
              className={`px-2 py-1 text-xs rounded ${
                currentDebugRegion === "china"
                  ? "bg-yellow-600 text-white"
                  : "bg-yellow-200 text-yellow-800 hover:bg-yellow-300"
              }`}
            >
              中国
            </button>
            <button
              onClick={() => toggleDebugMode("usa")}
              className={`px-2 py-1 text-xs rounded ${
                currentDebugRegion === "usa"
                  ? "bg-yellow-600 text-white"
                  : "bg-yellow-200 text-yellow-800 hover:bg-yellow-300"
              }`}
            >
              美国
            </button>
            <button
              onClick={() => toggleDebugMode(null)}
              className="px-2 py-1 text-xs rounded bg-gray-200 text-gray-800 hover:bg-gray-300"
            >
              退出调试
            </button>
          </div>
        </div>
      )}

      <div className="flex h-[calc(100vh-64px)]">
        <Sidebar
          selectedGPTs={selectedGPTs}
          setSelectedGPTs={setSelectedGPTs}
          collaborationMode={collaborationMode}
          setCollaborationMode={(mode) =>
            setCollaborationMode(mode as "parallel" | "sequential")
          }
        />

        <main className="flex-1 overflow-auto">
          {activeView === "workspace" && (
            <GPTWorkspace
              selectedGPTs={selectedGPTs}
              collaborationMode={collaborationMode}
            />
          )}
          {activeView === "library" && (
            <GPTLibrary
              selectedGPTs={selectedGPTs}
              setSelectedGPTs={setSelectedGPTs}
              collaborationMode={collaborationMode}
              setCollaborationMode={(mode) =>
                setCollaborationMode(mode as "parallel" | "sequential")
              }
            />
          )}
          {activeView === "export" && (
            <ExportPanel selectedGPTs={selectedGPTs} />
          )}
          {activeView === "history" && <ChatHistory />}
        </main>
      </div>
    </div>
  );
}
